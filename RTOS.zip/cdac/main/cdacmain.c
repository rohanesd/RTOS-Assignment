#include <stdio.h>

int app_main()
{
    printf("Hello C-DAC\n");
    return 0;
}